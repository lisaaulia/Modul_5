/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TCP;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

/**
 *
 * @author ASUS
 */
public class AudioServer {
    public static final int SERVICE_PORT = 13;
    public static final int BUFSIZE = 4096;
    public static void main(String[] args){
        InputStream in;
        OutputStream out;
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        try{
            for(;;){
                ServerSocket server = new ServerSocket(SERVICE_PORT);
                System.out.println("Server is getting started");
                Socket Client = server.accept();
                in = Client.getInputStream();
                out = new ByteArrayOutputStream();
                byte [] sizeArray = new byte[BUFSIZE];
                in.read(sizeArray);
                in = Client.getInputStream();
                int r = in.read();
                while(r!=-1){
                    out.write(r);
                    bout = (ByteArrayOutputStream) out;
                    r=in.read();
                }
                out.flush();
                out.close();
                System.out.println("Data Received!");
                byte buffer [] = bout.toByteArray();
                ByteArrayInputStream bin = new ByteArrayInputStream(buffer);
                AudioStream au = new AudioStream(bin);
                AudioPlayer.player.start(au);
            }
        }catch(BindException be){
        
        }catch(IOException ioe){
        
        }
    }
}
