/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TCP;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author ASUS
 */
public class DataServer {
    public static final int SERVICE_PORT = 13;
    
    public static void main(String[] args) {
        try{
            //Find to the service port, to grant clients access to the TCP daytime services
            ServerSocket server = new ServerSocket(SERVICE_PORT);
            System.out.println("Daytime server satrted");
            
            //Loop indefinitely, accepting clients
            for(;;){
                //Get the next TCP Client
                Socket newClient = server.accept();
                
                BufferedReader reader = new BufferedReader(new InputStreamReader(newClient.getInputStream()));
                String receivedMessage = reader.readLine();
                System.out.println("Message : "+receivedMessage);
                System.out.println("Received Request from "+newClient.getInetAddress()+" : "+ newClient.getPort());
                try(FileOutputStream fou = new FileOutputStream("d:/dataClient.txt")){
                    for(int i=0; i< receivedMessage.length();i++){
                        fou.write(receivedMessage.charAt(i));
                    }
                }catch(IOException ioe){
                    System.out.println(ioe);
                }
                //Display connection details
                
                //close the connections
                newClient.close();
            }
        }catch(BindException be){
            System.err.println("Service already running on port "+SERVICE_PORT);
        }catch(IOException ioe){
            System.err.println("I/O Error "+ioe);
        }
    }
}
