/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TCP;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;

/**
 *
 * @author ASUS
 */
public class AudioClient {
    public static final int SERVICE_PORT = 13;
    public static void main(String[] args) {
        String hostname ="localhost";
        File file = new File("d:/bbm_tone.wav");
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        OutputStream out;
        InputStream inp;
        try{
            for(;;){
                System.out.println("Server is getting started");
                Socket Client =  new Socket(hostname, SERVICE_PORT);
                inp = new FileInputStream(file);
                out = new ByteArrayOutputStream();
                int data = inp.read();
                while (data != -1) {
                    out.write(data);
                    bout = (ByteArrayOutputStream) out;
                    data = inp.read();
                }
                out.flush();
                out.close();
                byte[] size = ByteBuffer.allocate(4).putInt(bout.size()).array();
                out = Client.getOutputStream();
                out.write(size);
                out.write(bout.toByteArray());
                out.flush();
                out.close();
                System.out.println("File sent!");
            }
        }catch(BindException be){
        
        }catch(IOException ioe){
        
        }
    }
}
