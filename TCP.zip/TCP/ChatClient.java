/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TCP;

import java.awt.Image;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import javax.imageio.ImageIO;

/**
 *
 * @author ASUS
 */
public class ChatClient {
    
    public static final int SERVICE_PORT = 13;

    public static void main(String[] args) throws FileNotFoundException, IOException {

        BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
        String hostname = "localhost";
        OutputStream out;
        InputStream in;
             
                    in = new FileInputStream("d:/fikri.jpg");
                    int a = in.read();
               
                    while(a!=-1){     
                        a =  in.read();
                    }
                    in.close();
              
            try {
                
                //Get a scket to a daytime service
                Socket daytime = new Socket(hostname, SERVICE_PORT);
                
                System.out.println("Connection Established");
                //Get the socket option just in case server stalls
                daytime.setSoTimeout(2000);                
                //Just write the message
                out = daytime.getOutputStream();
                PrintStream pout = new PrintStream(out);
                //Write the useless message
                pout.print(a);
                //Flush current bytes
                out.flush();
                out.close();
//                Socket newReply = new Socket(hostname, SERVICE_PORT);
//                BufferedReader reader2 = new BufferedReader(new InputStreamReader(newReply.getInputStream()));
//                System.out.println("Replied Message : "+reader2.readLine());
            } catch (Exception ioe) {
                System.out.println("Error " + ioe);
            }
        
    }
}
