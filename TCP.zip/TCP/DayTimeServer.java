/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TCP;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author ASUS
 */
public class DayTimeServer {
    public static final int SERVICE_PORT = 13;
    
    public static void main(String[] args) {
        try{
            //Find to the service port, to grant clients access to the TCP daytime services
            ServerSocket server = new ServerSocket(SERVICE_PORT);
            System.out.println("Daytime server started");
            
            //Loop indefinitely, accepting clients
            for(;;){
                //Get the next TCP Client
                Socket nextClient = server.accept();
                System.out.println("Accepted");
                //Display connection details
                System.out.println("Received Request from "+nextClient.getInetAddress()+" : "+ nextClient.getPort());
                
                //Just write the message
                OutputStream out = nextClient.getOutputStream();
                PrintStream pout = new PrintStream(out);
                
                //Write teh current date out to the user
                pout.print("cok");
                
                //Flush current bytes
                out.flush();
                
                //Close Stream
                out.close();
                
                //close the connections
                nextClient.close();
                
            }
        }catch(BindException be){
            System.err.println("Service already running on port "+SERVICE_PORT);
        }catch(IOException ioe){
            System.err.println("I/O Error "+ioe);
        }
    }
}
