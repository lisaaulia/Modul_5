/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TCP;

import java.awt.Image;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import javax.imageio.ImageIO;

/**
 *
 * @author ASUS
 */
public class MessageClient {

    public static final int SERVICE_PORT = 13;

    public static void main(String[] args) {

        BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
        
            try {
                String hostname = "localhost";

                //Get a scket to a daytime service
                Socket daytime = new Socket(hostname, SERVICE_PORT);
                System.out.println("Connection Established");

                //Get the socket option just in case server stalls
                daytime.setSoTimeout(2000);
                FileInputStream fis = new FileInputStream("d:/hikam.jpg");
                //Just write the message
                OutputStream out = daytime.getOutputStream();
                PrintStream pout = new PrintStream(out);
                System.out.println("Just Write an useless message : ");
                Image image = null;
                image = ImageIO.read(fis);
                //Write the useless message
                pout.print(image);

                //Flush current bytes
                out.flush();
                out.close();
                
            } catch (IOException ioe) {
                System.out.println("Error " + ioe);
            }
     
    }
}
