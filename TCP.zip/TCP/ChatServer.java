/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TCP;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import static javax.swing.WindowConstants.HIDE_ON_CLOSE;

/**
 *
 * @author ASUS
 */
public class ChatServer {
    public static final int SERVICE_PORT = 13;
    
    public static void main(String[] args) {
        BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
        try{
            //Find to the service port, to grant clients access to the TCP daytime services
            ServerSocket server = new ServerSocket(SERVICE_PORT);
            System.out.println("Daytime server satrted");
            //Loop indefinitely, accepting clients
            
                //Get the next TCP Client
                Socket newClient = server.accept();
                InputStream in = newClient.getInputStream();
                int b = in.read();
                OutputStream out = new FileOutputStream("d:/hikam.jpg");
                while(b!=-1){
                    out.write(b);
                    b = in.read();
                }
                out.flush();
                out.close();
                File sf = new File("d:/hikam.jpg");
                Image image = ImageIO.read(sf);
                JFrame frame = new JFrame();
                frame.setDefaultCloseOperation(HIDE_ON_CLOSE);
                frame.setLocation(300, 100);
                JLabel label = new JLabel(new ImageIcon(image));
                frame.getContentPane().add(label, BorderLayout.CENTER);
                frame.pack();
                frame.setVisible(true);
                System.out.println("Received Request from "+newClient.getInetAddress()+" : "+ newClient.getPort());
                newClient.close();
                
//                Socket newClient2 = server.accept();
//                System.out.print("Just Write a replied message : ");
//                OutputStream out = newClient2.getOutputStream();
//                PrintStream pout = new PrintStream(out);
//                String reply = buf.readLine();
//                pout.print(reply);
//                out.flush();
//                out.close();
//                newClient2.close();
            
        }catch(BindException be){
            System.err.println("Service already running on port "+SERVICE_PORT);
        }catch(IOException ioe){
            System.err.println("I/O Error "+ioe);
        }
    }
}
