/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package TCP;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

/**
 *
 * @author ASUS
 */
public class DayTimeClient {
    public static final int SERVICE_PORT= 13;
    public static void main(String[] args) {
        try{
            String hostname ="localhost";
            
            //Get a scket to a daytime service
            Socket daytime = new Socket(hostname, SERVICE_PORT);
            System.out.println("Connection Established");
            
            //Get teh socket option just in case server stalls
            daytime.setSoTimeout(2000);
            BufferedReader reader = new BufferedReader(new InputStreamReader(daytime.getInputStream()));
            System.out.println("Result : "+reader.readLine());
            
            //Close the connection
            daytime.close();
        }catch(IOException ioe){
            System.out.println("Error "+ioe);
        }
    }
}
